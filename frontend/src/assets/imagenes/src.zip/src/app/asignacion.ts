export interface Asignacion {
    idEntrenador: Number;
    idCliente: Number;
}
