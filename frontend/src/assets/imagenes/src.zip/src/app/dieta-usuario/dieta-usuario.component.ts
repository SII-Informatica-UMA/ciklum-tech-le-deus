import { Component } from '@angular/core';

@Component({
  selector: 'app-dieta-usuario',
  standalone: true,
  imports: [],
  templateUrl: './dieta-usuario.component.html',
  styleUrl: './dieta-usuario.component.css'
})
export class DietaUsuarioComponent {

}
