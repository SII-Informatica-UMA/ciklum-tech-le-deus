package ciklumtechledeus.entidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DietasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DietasApplication.class, args);
	}

}
